#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>
#include <set>
#include <ctime>
#include <string>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    int R = inf.readInt(1, 100, "R");
    inf.readSpace();
    int r1 = inf.readInt(1, 100, "r1");
    inf.readSpace();
    int r2 = inf.readInt(1, 100, "r2");
    inf.readEoln();
    for(int i = 0; i < 20; ++i) {
        int a;
        a = inf.readInt(1, 100, "ai");
        if(i != 19) {
            inf.readSpace();
        }
    }
    inf.readEoln();
    int n = inf.readInt(1, 1000, "n");
    inf.readEoln();
    for(int i = 0; i < n * 2; ++i) {
        int x, y;
        x = inf.readInt(-100, 100, "xi");
        inf.readSpace();
        y = inf.readInt(-100, 100, "yi");
        inf.readEoln();
    }
    inf.readEof();
}