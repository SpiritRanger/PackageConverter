#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>
#include <set>
#include <ctime>
#include <string>
#include "testlib.h"


using namespace std;

const double pi = 3.14159265359;
const double eps = 1e-8;

bool f(int r1, int r2, int R, pair<int, int> p);

void rotate(pair<double, double> &p, double alpha);

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int maxR = atoi(argv[1]);
    int maxN = atoi(argv[2]);
    int maxA = atoi(argv[3]);
    int R = rnd.next(3, maxR);
    int r2 = rnd.next(2, R - 1);
    int r1 = rnd.next(1, r2 - 1);
    vector<int> a(20);
    for(int i = 0; i < 20; ++i){
        a[i] = rnd.next(1, maxA);
    }
    int n = rnd.next(1, maxN);
    vector<pair<int, int>> v(n);
    vector<pair<int, int>> p(n);
    for(int i = 0; i < n; ++i) {
        do {
            v[i].first = rnd.next(-100, 100);
            v[i].second = rnd.next(-100, 100);
        } while(!f(r1, r2, R, v[i]));
    }
    for(int i = 0; i < n; ++i) {
        do {
            p[i].first = rnd.next(-100, 100);
            p[i].second = rnd.next(-100, 100);
        } while(!f(r1, r2, R, p[i]));
    }
    printf("%d %d %d\n", R, r1, r2);
    for(int i = 0; i < 20; ++i) {
        printf("%d", a[i]);
        if(i != 19) {
            printf(" ");
        }
    }
    printf("\n%d\n", n);
    for(int i = 0; i < n; ++i) {
        printf("%d %d\n", v[i].first, v[i].second);
    }
    for(int i = 0; i < n; ++i) {
        printf("%d %d\n", p[i].first, p[i].second);
    }
    return 0;
}

bool f(int r1, int r2, int R, pair<int, int> p) {
    if(p.first * p.first + p.second * p.second == R * R ) {
        return 0;
    }
    if(p.first * p.first + p.second * p.second == r1 * r1 ) {
        return 0;
    }
    if(p.first * p.first + p.second * p.second == r2 * r2 ) {
        return 0;
    }
    if(p.first * p.first + p.second * p.second > r2 * r2 && p.first * p.first + p.second * p.second  < R * R) {
        double alpha = pi / 20.0;
        pair<double, double> v = make_pair(1, 0);
        rotate(v, alpha);
        alpha = (pi / 10.0);
        pair<double, double> t = p;
        for(int i = 0; i < 20; ++i) {
            if(!t.first && !t.second) {
                return 0;
            }
            if(!t.first || !t.second) {
                rotate(v, alpha);
                continue;
            }
            if(fabs(t.second / t.first - v.second / v.first) < eps) {
                return 0;
            }
            rotate(v, alpha);
        }
    }
    return 1;
}

void rotate(pair<double, double> &p, double alpha) {
    pair<double, double> ans;
    ans.first = p.first * cos(alpha) - p.second * sin(alpha);
    ans.second = p.first * sin(alpha) + p.second * cos(alpha);
    p = ans;
}