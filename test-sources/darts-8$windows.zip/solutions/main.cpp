#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>
#include <set>
#include <ctime>
#include <string>


using namespace std;

const double pi = 3.14159265359;
const double eps = 1e-8;

int seg(pair<int, int> p);

int dist(pair<int, int> p);

int main(int argc, char* argv[]) {
    int r1, r2, R;
    scanf("%d%d%d", &R, &r1, &r2);
    vector<int> a(20);
    for(int i = 0; i < 20; ++i) {
        scanf("%d", &a[i]);
    }
    int n;
    scanf("%d", &n);
    vector<pair<int, int>> p(n), v(n);
    for(int i = 0; i < n; ++i) {
        scanf("%d%d", &v[i].first, &v[i].second);
    }
    for(int i = 0; i < n; ++i) {
        scanf("%d%d", &p[i].first, &p[i].second);
    }
    int pet = 0, vas = 0;
    for(int i = 0; i < n; ++i){
        if(dist(v[i]) < r1 * r1) {
            vas += 50;
            continue;
        }
        if(dist(v[i]) < r2 * r2) {
            vas += 25;
            continue;
        }
        if(dist(v[i]) < R * R) {
            int s = seg(v[i]);
            vas += a[s];
        }
    }
    for(int i = 0; i < n; ++i){
        if(dist(p[i]) < r1 * r1) {
            pet += 50;
            continue;
        }
        if(dist(p[i]) < r2 * r2) {
            pet += 25;
            continue;
        }
        if(dist(p[i]) < R * R) {
            int s = seg(p[i]);
            pet += a[s];
        }
    }
    if(pet > vas) {
        printf("Petya\n");
    }
    if(vas > pet) {
        printf("Vasya\n");
    }
    if(vas == pet) {
        printf("Draw\n");
    }
    printf("%d %d", vas, pet);
    return 0;
}

int seg(pair<int, int> p) {
    pair<double, double> tp = p;
    if(p.first == 0 && p.second > 0) {
        return 0;
    }
    if(p.first == 0 && p.second < 0) {
        return 10;
    }
    double betta = atan(fabs(tp.second) / fabs(tp.first));
    if(p.first > 0 && p.second < 0) {
        betta = 2.0 * pi - betta;
    }
    if(p.first < 0 && p.second >= 0) {
        betta = pi - betta;
    }
    if(p.first < 0 && p.second < 0) {
        betta = pi + betta;
    }
    double alpha1 = pi / 2.0 + pi / 20.0, alpha2 = pi / 2.0 - pi / 20.0, fi = pi / 10.0;
    for(int i = 0; i < 20; ++i) {
        if(alpha1 > alpha2) {
            if (betta > alpha2 && betta < alpha1) {
                return i;
            }
        } else {
            if(betta < alpha1 && betta + 2.0 * pi > alpha2) {
                return i;
            }
            if(betta > alpha2 && betta < alpha1 + 2.0 * pi) {
                return i;
            }
        }
        alpha1 = alpha2;
        alpha2 -= fi;
        if(alpha2 < 0) {
            alpha2 += 2 * pi;
        }
    }
}

int dist(pair<int, int> p) {
    int ans = p.first * p.first + p.second * p.second;
    return ans;
}